# Flappy bird
Flappy bird game with JS, CSS, HTML
   * https://github.com/nishat-nasir/flappybird
  - Run htm.html file to see the game.
  - There are comments to UI according to your choice
